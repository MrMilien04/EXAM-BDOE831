SELECT
    logs.*,
    geo.iso_code as country_code
FROM
    "BDOE831_network_logs-ip-format" logs
LEFT JOIN
    "BDOE831_dbip_country-ip-format" geo
ON
    logs."Source_IP_int" >= geo.start_ip_int
    AND logs."Source_IP_int" <= geo.end_ip_int