SELECT
    logs.*,
    geo.iso_code as country_code
FROM
    "BDOE831_network_logs-with-country-code" logs
LEFT JOIN
    "BDOE831_dbip_country-ip-format" geo
ON
    logs."Destination_IP_int" >= geo.start_ip_int
    AND logs."Destination_IP_int" <= geo.end_ip_int